#!/bin/bash

echo "--------------"
echo "CLEANING UP"
echo "--------------"

rm -r family_1/Generation_*
rm -r family_1/vars_*.txt
rm -r Gridsearch/Run*

echo "-----------------"
echo "DONE CLEANING UP"
echo "-----------------"





